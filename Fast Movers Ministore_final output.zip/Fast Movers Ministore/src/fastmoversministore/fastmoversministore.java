
package fastmoversministore;

public class fastmoversministore {

    public static void main(String[] args) {
        // TODO code application logic here
        Login e = new Login();
        e.setVisible(true);
    }
    
}
