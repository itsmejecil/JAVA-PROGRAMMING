/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fastmoversministore;

import com.mysql.cj.x.protobuf.MysqlxCrud.Insert;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author student.admin
 */
public class Inventory extends javax.swing.JFrame {

    /**
     * Creates new form Inventory
     */
    Connection con;
    PreparedStatement pst;
    ResultSet rs;

    public Inventory() {
        initComponents();
//        table_update();
        display();

    }

    private void table_update() {
        try {
            int minimart;
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/fast movers minimart", "root", "");
                pst = (PreparedStatement) con.prepareStatement("select * from inventory where status!='deleted'");
                ResultSet rs = (ResultSet) pst.executeQuery();

                ResultSetMetaData set = (ResultSetMetaData) rs.getMetaData();
                minimart = set.getColumnCount();

                DefaultTableModel dtm = (DefaultTableModel) jTable1.getModel();
                dtm.setRowCount(0);

                while (rs.next()) {
                    Vector vc = new Vector();

                    for (int i = 1; i <= minimart; i++) {
                        vc.add(rs.getString(1));
                        vc.add(rs.getString(2));
                        vc.add(rs.getString(3));
                        vc.add(rs.getString(4));
                        vc.add(rs.getString(5));
                        vc.add(rs.getString(6));
                        vc.add(rs.getString(7));
                        vc.add(rs.getString(8));
                    }

                    dtm.addRow(vc);
                }

            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
            }

        } catch (SQLException ex) {
            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void display() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/fast movers minimart", "root", "");
            pst = (PreparedStatement) con.prepareStatement("select * from inventory where status!='deleted'");
            ResultSet rs = (ResultSet) pst.executeQuery();

            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0);

            while (rs.next()) {
                model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8)});

            }
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("Error : " + ex.getMessage());
        }
    }

    /**
     *
     * @throws SQLException
     */
    public void Connect() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/fast movers minimart", "root", "");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {     
            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        inventoryID = new javax.swing.JTextField();
        productname = new javax.swing.JTextField();
        description = new javax.swing.JTextField();
        buyingprice = new javax.swing.JTextField();
        sellingprice = new javax.swing.JTextField();
        unitofmeasure = new javax.swing.JTextField();
        expirationdate = new javax.swing.JTextField();
        quantity = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        update = new javax.swing.JButton();
        add = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        view = new javax.swing.JButton();
        login = new javax.swing.JButton();
        stafftransaction = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        minimizebtn = new javax.swing.JButton();
        exitbtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel2.setBackground(new java.awt.Color(255, 203, 130));

        jPanel3.setBackground(new java.awt.Color(255, 102, 0));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setText("InventoryID:");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel3.setText("Product Name:");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel4.setText("Description:");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel5.setText("Buying Price:");

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel6.setText("Selling Price:");

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel7.setText("Quantity:");

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel8.setText("Expiration Date:");

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel9.setText("Unit of Measure:");

        inventoryID.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        inventoryID.setForeground(new java.awt.Color(255, 102, 0));
        inventoryID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inventoryIDActionPerformed(evt);
            }
        });

        productname.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        productname.setForeground(new java.awt.Color(255, 102, 0));

        description.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        description.setForeground(new java.awt.Color(255, 102, 0));

        buyingprice.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        buyingprice.setForeground(new java.awt.Color(255, 102, 0));

        sellingprice.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        sellingprice.setForeground(new java.awt.Color(255, 102, 0));

        unitofmeasure.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        unitofmeasure.setForeground(new java.awt.Color(255, 102, 0));

        expirationdate.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        expirationdate.setForeground(new java.awt.Color(255, 102, 0));

        quantity.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        quantity.setForeground(new java.awt.Color(255, 102, 0));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(79, 79, 79)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(expirationdate, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(unitofmeasure, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sellingprice, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buyingprice, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(description, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(productname, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(inventoryID, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quantity, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(56, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(inventoryID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(productname))
                .addGap(24, 24, 24)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(description))
                .addGap(24, 24, 24)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buyingprice))
                .addGap(21, 21, 21)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sellingprice))
                .addGap(21, 21, 21)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quantity, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(unitofmeasure))
                .addGap(18, 18, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(expirationdate))
                .addGap(69, 69, 69))
        );

        jPanel4.setBackground(new java.awt.Color(255, 102, 0));
        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        update.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        update.setForeground(new java.awt.Color(255, 102, 0));
        update.setText("Update");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });

        add.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        add.setForeground(new java.awt.Color(255, 102, 0));
        add.setText("Add");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });

        delete.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        delete.setForeground(new java.awt.Color(255, 102, 0));
        delete.setText("Delete");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });

        view.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        view.setForeground(new java.awt.Color(255, 102, 0));
        view.setText("View");
        view.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewActionPerformed(evt);
            }
        });

        login.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        login.setForeground(new java.awt.Color(255, 102, 0));
        login.setText("Login");
        login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginActionPerformed(evt);
            }
        });

        stafftransaction.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        stafftransaction.setForeground(new java.awt.Color(255, 102, 0));
        stafftransaction.setText("Staff Transactions");
        stafftransaction.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stafftransactionActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(154, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(add, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(login, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(stafftransaction, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(view, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(delete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(update, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(123, 123, 123))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(login)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(add)
                .addGap(33, 33, 33)
                .addComponent(update)
                .addGap(33, 33, 33)
                .addComponent(delete)
                .addGap(40, 40, 40)
                .addComponent(view)
                .addGap(34, 34, 34)
                .addComponent(stafftransaction)
                .addGap(54, 54, 54))
        );

        jTable1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "InventoryID", "ProductName", "Description", "Buying Price", "Selling Price", "Quantity", "Unit of Measure", "Expiration Date"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel1.setFont(new java.awt.Font("Poor Richard", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 102, 0));
        jLabel1.setText("JECIL'S FAST MOVERS MINIMART INVENTORY");

        jLabel11.setIcon(new javax.swing.ImageIcon("C:\\Users\\student.admin\\Downloads\\images-removebg-preview.png")); // NOI18N

        minimizebtn.setBackground(new java.awt.Color(255, 255, 255));
        minimizebtn.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        minimizebtn.setForeground(new java.awt.Color(255, 102, 0));
        minimizebtn.setText("-");
        minimizebtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                minimizebtnMouseClicked(evt);
            }
        });
        minimizebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minimizebtnActionPerformed(evt);
            }
        });

        exitbtn.setBackground(new java.awt.Color(255, 255, 255));
        exitbtn.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        exitbtn.setForeground(new java.awt.Color(255, 102, 0));
        exitbtn.setText("x");
        exitbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitbtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 1161, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(26, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(47, 47, 47)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 792, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(minimizebtn)
                                .addGap(18, 18, 18)
                                .addComponent(exitbtn)
                                .addContainerGap())))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(minimizebtn)
                            .addComponent(exitbtn))
                        .addGap(19, 19, 19)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 481, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 37, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 2, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents


    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
        // TODO add your handling code here:
        String date = java.time.LocalDate.now().toString();
        String time = java.time.LocalTime.now().toString();

        String inventoryid = inventoryID.getText();
        String pname = productname.getText();
        String descript = description.getText();
        String bprice = buyingprice.getText();
        String sprice = sellingprice.getText();
        String qty = quantity.getText();
        String unitofmeas = unitofmeasure.getText();
        String expiration = expirationdate.getText();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/fast movers minimart", "root", "");
            pst = (PreparedStatement) con.prepareStatement("insert into inventory( ProductName, Description, BuyingPrice, SellingPrice,Quantity,UnitOfMeasure,ExpirationDate)values(?,?,?,?,?,?,?)");

//            pst.setString(1, inventoryid);
            pst.setString(1, pname);
            pst.setString(2, descript);
            pst.setString(3, bprice);
            pst.setString(4, sprice);
            pst.setString(5, qty);
            pst.setString(6, unitofmeas);
            pst.setString(7, expiration);

            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Added Successfully!");
            }

        } catch (SQLException ex) {
            System.out.println("Error : " + ex.getMessage());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
        }
        display();

        try {

            String lrow = jTable1.getValueAt(jTable1.getModel().getRowCount() - 1, 0).toString();
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/fast movers minimart", "root", "");
            pst = (PreparedStatement) con.prepareStatement("INSERT INTO stransactions( InventoryID, Quantity,TypeOfTransaction, UserID, Date, Time) VALUES (?,?,?,?,?,?)");

            pst.setString(1, lrow);
            pst.setString(2, qty);
            pst.setString(3, "Add inventory");
            pst.setInt(4, new Login().userID());
            pst.setString(5, date);
            pst.setString(6, time);

            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Added Successfully!");
            }

        } catch (SQLException ex) {
            System.out.println("Error : " + ex.getMessage());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_addActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
        // TODO add your handling code here:
        String date = java.time.LocalDate.now().toString();
        String time = java.time.LocalTime.now().toString();
        
        String inventoryid = inventoryID.getText();
        String qty = quantity.getText();
        try {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost/fast movers minimart", "root", "");
                pst = con.prepareStatement("update inventory set InventoryID=?,ProductName=?,Description=?,BuyingPrice=?,SellingPrice=?, Quantity=?,UnitOfMeasure=? ,ExpirationDate=? where InventoryID=?");

                pst.setString(1, inventoryID.getText());
                pst.setString(2, productname.getText());
                pst.setString(3, description.getText());
                pst.setString(4, buyingprice.getText());
                pst.setString(5, sellingprice.getText());
                pst.setString(6, quantity.getText());
                pst.setString(7, unitofmeasure.getText());
                pst.setString(8, expirationdate.getText());
                pst.setString(9, inventoryID.getText());

                pst.execute();
                JOptionPane.showMessageDialog(null, "Details updated");
            } catch (Exception e) {
                Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, e);
            }
        } catch (Exception e) {
            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, e);
        }

        inventoryID.setText("");
        productname.setText("");
        description.setText("");
        buyingprice.setText("");
        sellingprice.setText("");
        quantity.setText("");
        unitofmeasure.setText("");
        expirationdate.getText();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/fast movers minimart", "root", "");
            pst = (PreparedStatement) con.prepareStatement("INSERT INTO stransactions( InventoryID, Quantity, TypeOfTransaction, UserID, Date, Time) VALUES (?,?,?,?,?,?)");

            pst.setString(1, inventoryid);
            pst.setString(2, qty);
            pst.setString(3, "Update inventory");
            pst.setInt(4, new Login().userID());
            pst.setString(5, date); 
            pst.setString(6, time);

            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Updated Successfully!");
            }

        } catch (SQLException ex) {
            System.out.println("Error : " + ex.getMessage());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
        }


    }//GEN-LAST:event_updateActionPerformed

    private void viewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewActionPerformed
          // TODO add your handling code here:
        int fastmoversminimart;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/fast movers minimart", "root", "");
            pst = (PreparedStatement) con.prepareStatement("select * from inventory");
            ResultSet rs = (ResultSet) pst.executeQuery();

            ResultSetMetaData set = (ResultSetMetaData) rs.getMetaData();
            fastmoversminimart = set.getColumnCount();

            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0);

            while (rs.next()) {
                model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8)});

            }
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("Error : " + ex.getMessage());
        }
    }//GEN-LAST:event_viewActionPerformed


    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        // TODO add your handling code here:
        String date = java.time.LocalDate.now().toString();
        String time = java.time.LocalTime.now().toString();

        String inventoryid = inventoryID.getText();
        String qty = quantity.getText();
        DefaultTableModel dtm1 = (DefaultTableModel) jTable1.getModel();
        int selectIndex = jTable1.getSelectedRow();

        int id = Integer.parseInt(dtm1.getValueAt(selectIndex, 0).toString());

        int dialogResult = JOptionPane.showConfirmDialog(null, "Do you want to Remove this ?", "Warning", JOptionPane.YES_NO_OPTION);

        if (dialogResult == JOptionPane.YES_OPTION) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/fast movers minimart", "root", "");
                pst = (PreparedStatement) con.prepareStatement("UPDATE inventory SET status=? WHERE InventoryID=?");
                pst.setString(1, "deleted");

                pst.setInt(2, id);
                pst.executeUpdate();
                JOptionPane.showMessageDialog(null, " Successfully Deleted!");
                table_update();

            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/fast movers minimart", "root", "");
            pst = (PreparedStatement) con.prepareStatement("INSERT INTO stransactions( InventoryID, Quantity, TypeOfTransaction, UserID, Date, Time) VALUES (?,?,?,?,?,?)");

            pst.setString(1, inventoryid);
            pst.setString(2, qty);
            pst.setString(3, "Delete inventory");
            pst.setInt(4, new Login().userID());
            pst.setString(5, date);
            pst.setString(6, time);

            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Deleted Successfully!");
            }

        } catch (SQLException ex) {
            System.out.println("Error : " + ex.getMessage());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
        }
        inventoryID.setText("");
        productname.setText("");
        description.setText("");
        buyingprice.setText("");
        sellingprice.setText("");
        unitofmeasure.setText("");
        expirationdate.setText("");
    }//GEN-LAST:event_deleteActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
          // TODO add your handling code here:
        DefaultTableModel dtm1 = (DefaultTableModel) jTable1.getModel();
        try {
            int selectIndex = jTable1.getSelectedRow();

            String inventoryid = inventoryID.getText();
            String pName = productname.getText();
            String descript = description.getText();
            String bprice = buyingprice.getText();
            String sprice = sellingprice.getText();
            String qty = quantity.getText();
            String unitofmeas = unitofmeasure.getText();
            String expiration = expirationdate.getText();

            inventoryID.setText(dtm1.getValueAt(selectIndex, 0).toString());
            productname.setText(dtm1.getValueAt(selectIndex, 1).toString());
            description.setText(dtm1.getValueAt(selectIndex, 2).toString());
            buyingprice.setText(dtm1.getValueAt(selectIndex, 3).toString());
            sellingprice.setText(dtm1.getValueAt(selectIndex, 4).toString());
            quantity.setText(dtm1.getValueAt(selectIndex, 5).toString());
            unitofmeasure.setText(dtm1.getValueAt(selectIndex, 6).toString());
            expirationdate.setText(dtm1.getValueAt(selectIndex, 7).toString());

        } catch (ArrayIndexOutOfBoundsException indexout) {
        }
        DefaultTableModel tblModel = (DefaultTableModel) jTable1.getModel();

        String inventoryid = tblModel.getValueAt(jTable1.getSelectedRow(), 0).toString();
        String pName = tblModel.getValueAt(jTable1.getSelectedRow(), 1).toString();
        String descript = tblModel.getValueAt(jTable1.getSelectedRow(), 2).toString();
        String bprice = tblModel.getValueAt(jTable1.getSelectedRow(), 3).toString();
        String sprice = tblModel.getValueAt(jTable1.getSelectedRow(), 4).toString();
        String qty = tblModel.getValueAt(jTable1.getSelectedRow(), 5).toString();
        String unitofmeas = tblModel.getValueAt(jTable1.getSelectedRow(), 6).toString();
        String expiration = tblModel.getValueAt(jTable1.getSelectedRow(), 7).toString();

        inventoryID.setText(inventoryid);
        productname.setText(pName);
        description.setText(descript);
        buyingprice.setText(bprice);
        sellingprice.setText(sprice);
        quantity.setText(qty);
        unitofmeasure.setText(unitofmeas);
        expirationdate.setText(expiration);
    }//GEN-LAST:event_jTable1MouseClicked

    private void loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginActionPerformed
        // TODO add your handling code here:
        Login l = new Login();
        this.dispose();
        l.setVisible(true);
    }//GEN-LAST:event_loginActionPerformed

    private void stafftransactionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stafftransactionActionPerformed

        new Staff().setVisible(true);
    }//GEN-LAST:event_stafftransactionActionPerformed

    private void inventoryIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inventoryIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_inventoryIDActionPerformed

    private void minimizebtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimizebtnMouseClicked
        // TODO add your handling code here:
        setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_minimizebtnMouseClicked

    private void minimizebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minimizebtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_minimizebtnActionPerformed

    private void exitbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitbtnActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_exitbtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inventory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inventory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inventory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inventory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inventory().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add;
    private javax.swing.JTextField buyingprice;
    private javax.swing.JButton delete;
    private javax.swing.JTextField description;
    private javax.swing.JButton exitbtn;
    private javax.swing.JTextField expirationdate;
    private javax.swing.JTextField inventoryID;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private static javax.swing.JTable jTable1;
    private javax.swing.JButton login;
    private javax.swing.JButton minimizebtn;
    private javax.swing.JTextField productname;
    private javax.swing.JTextField quantity;
    private javax.swing.JTextField sellingprice;
    private javax.swing.JButton stafftransaction;
    private javax.swing.JTextField unitofmeasure;
    private javax.swing.JButton update;
    private javax.swing.JButton view;
    // End of variables declaration//GEN-END:variables

}
